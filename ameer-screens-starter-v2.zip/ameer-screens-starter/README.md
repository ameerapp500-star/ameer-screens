# Ameer Screens Player
Android application source for Ameer Screens. Build with Gradle 8.11.1 and JDK 17.
The project keeps the existing activation endpoint and uses Android's Storage Access Framework for media and folder access.
