package com.ameerscreens.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val serverUrl = "https://ameer-activation.ameerapp500.workers.dev"
    private val executor = Executors.newSingleThreadExecutor()
    private val REQ_VIDEO = 1001
    private val REQ_FOLDER = 1002
    private val REQ_AUDIO = 1003
    private val REQ_IMAGE = 1004
    private val bg = Color.rgb(8, 12, 22)
    private val panel = Color.rgb(18, 27, 43)
    private val panel2 = Color.rgb(25, 37, 57)
    private val cyan = Color.rgb(0, 204, 190)
    private val gold = Color.rgb(238, 184, 83)
    private val white = Color.WHITE
    private val muted = Color.rgb(151, 166, 188)
    private var folderUri: Uri? = null
    private var videoUri: Uri? = null
    private var videoName = "لم يتم اختيار فيديو"
    private var player: MediaPlayer? = null
    private var videoView: VideoView? = null
    private lateinit var root: LinearLayout
    private lateinit var scroll: ScrollView

    private fun d(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int = 18, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = d(radius).toFloat()
            if (stroke != 0) setStroke(d(1), stroke)
        }
    private fun label(s: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(d(18), d(18), d(18), d(28))
        setBackgroundColor(bg)
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }
    private fun space(parent: LinearLayout, h: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, d(h)))
    }
    private fun button(parent: LinearLayout, title: String, color: Int = panel2, action: () -> Unit) {
        val b = TextView(this).apply {
            text = title; textSize = 14f; setTextColor(white)
            gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD)
            background = shape(color, 14); setPadding(d(12), d(14), d(12), d(14))
            isClickable = true; isFocusable = true; setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(8) })
    }
    private fun card(parent: LinearLayout, title: String, subtitle: String, icon: String, color: Int, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(color, 18)
            setPadding(d(15), d(14), d(15), d(14))
            isClickable = true; isFocusable = true; setOnClickListener { action() }
        }
        box.addView(label(icon, 27f))
        space(box, 8)
        box.addView(label(title, 15f, white, true))
        space(box, 3)
        box.addView(label(subtitle, 11f, Color.rgb(205, 216, 231)))
        parent.addView(box, LinearLayout.LayoutParams(0, d(125), 1f).apply {
            marginStart = d(5); marginEnd = d(5); topMargin = d(5); bottomMargin = d(5)
        })
    }
    private fun section(parent: LinearLayout, title: String, action: String? = null, click: (() -> Unit)? = null) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(label(title, 18f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (action != null) {
            val more = label(action, 12f, cyan, true)
            more.setOnClickListener { click?.invoke() }
            row.addView(more)
        }
        parent.addView(row)
        space(parent, 10)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        getSharedPreferences("ameer", MODE_PRIVATE).getString("folder_uri", null)?.let { folderUri = Uri.parse(it) }
        if (getSharedPreferences("ameer", MODE_PRIVATE).getBoolean("activated", false)) home() else activation()
    }

    private fun activation() {
        val p = page().apply { gravity = Gravity.CENTER }
        p.addView(label("♛", 48f, gold, true).apply { gravity = Gravity.CENTER })
        p.addView(label("أمير للشاشات", 30f, white, true).apply { gravity = Gravity.CENTER })
        p.addView(label("AMEER SCREENS PLAYER", 12f, muted).apply { gravity = Gravity.CENTER })
        space(p, 30)
        val input = EditText(this).apply {
            hint = "أدخل كود التفعيل"; setTextColor(white); setHintTextColor(muted)
            setSingleLine(true); background = shape(panel, 14)
            setPadding(d(16), d(13), d(16), d(13))
        }
        p.addView(input, LinearLayout.LayoutParams(-1, -2))
        button(p, "تفعيل التطبيق", cyan) {
            val code = input.text.toString().trim()
            if (code.isEmpty()) { input.error = "أدخل كود التفعيل"; return@button }
            executor.execute {
                var ok = false
                var msg = "تعذر الاتصال بالخادم"
                try {
                    val c = URL(serverUrl).openConnection() as HttpURLConnection
                    c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 15000
                    c.doOutput = true; c.setRequestProperty("Content-Type", "application/json")
                    c.outputStream.use { it.write(JSONObject().put("code", code).toString().toByteArray()) }
                    val body = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
                    val json = JSONObject(body); ok = json.optBoolean("activated", false)
                    msg = json.optString("message", "كود غير صحيح"); c.disconnect()
                } catch (_: Exception) {}
                runOnUiThread {
                    if (ok) {
                        getSharedPreferences("ameer", MODE_PRIVATE).edit().putBoolean("activated", true).apply()
                        home()
                    } else AlertDialog.Builder(this).setMessage(msg).setPositiveButton("حسناً", null).show()
                }
            }
        }
        setContentView(p)
    }

    private fun home() {
        root = page()
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("أمير للشاشات", 24f, white, true))
        brand.addView(label("مشغل الوسائط الذكي", 11f, muted))
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(label("● جاهز", 12f, cyan, true).apply {
            background = shape(panel2, 30); setPadding(d(12), d(8), d(12), d(8))
        })
        root.addView(top)
        space(root, 18)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(14, 86, 104), Color.rgb(18, 42, 69))).apply { cornerRadius = d(22).toFloat() }
            setPadding(d(18), d(18), d(18), d(18))
        }
        hero.addView(label("كل ترفيهك بمكان واحد", 21f, white, true))
        space(hero, 5)
        hero.addView(label("شغّل فيديوهاتك واستعرض ملفاتك بسهولة", 12f, Color.rgb(218, 235, 242)))
        space(hero, 15)
        val play = TextView(this).apply {
            text = "▶    تشغيل فيديو"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(bg); setTypeface(null, Typeface.BOLD); background = shape(gold, 13)
            setPadding(d(12), d(13), d(12), d(13)); setOnClickListener { pick(REQ_VIDEO, "video/*") }
        }
        hero.addView(play); root.addView(hero)
        space(root, 22)

        section(root, "المشغل الآن")
        val playerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = shape(panel, 18)
            setPadding(d(12), d(12), d(12), d(12))
        }
        videoView = VideoView(this)
        playerCard.addView(videoView, LinearLayout.LayoutParams(-1, d(185)))
        playerCard.addView(label(videoName, 12f, muted).apply {
            gravity = Gravity.CENTER; setPadding(0, d(10), 0, d(8))
        })
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun ctl(t: String, action: () -> Unit) {
            val v = TextView(this).apply {
                text = t; textSize = 17f; gravity = Gravity.CENTER; setTextColor(white)
                background = shape(panel2, 12); setPadding(d(23), d(10), d(23), d(10))
                setOnClickListener { action() }
            }
            controls.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = d(4); marginEnd = d(4) })
        }
        ctl("▶") { if (videoUri == null) pick(REQ_VIDEO, "video/*") else videoView?.start() }
        ctl("Ⅱ") { videoView?.pause() }
        ctl("■") { videoView?.stopPlayback() }
        playerCard.addView(controls); root.addView(playerCard)
        space(root, 22)

        section(root, "مكتبتك", "عرض الكل") { showLibrary() }
        val row1 = LinearLayout(this)
        card(row1, "الفيديوهات", "استعراض وتشغيل", "▶", Color.rgb(31, 61, 103)) { showLibrary() }
        card(row1, "مدير الملفات", "اختيار مجلد كامل", "📁", Color.rgb(20, 91, 91)) { folders() }
        root.addView(row1)
        val row2 = LinearLayout(this)
        card(row2, "الموسيقى", "ملفاتك الصوتية", "♫", Color.rgb(74, 52, 105)) { pick(REQ_AUDIO, "audio/*") }
        card(row2, "الصور", "معرض الصور", "▧", Color.rgb(105, 66, 43)) { pick(REQ_IMAGE, "image/*") }
        root.addView(row2)
        val row3 = LinearLayout(this)
        card(row3, "المتصفح", "تصفح الإنترنت", "◎", Color.rgb(31, 75, 88)) { openBrowser() }
        card(row3, "الإعدادات", "خيارات التطبيق", "⚙", Color.rgb(54, 64, 82)) { settings() }
        root.addView(row3)
        space(root, 18)
        root.addView(label("AMEER SCREENS PLAYER  •  2.0", 10f, muted).apply { gravity = Gravity.CENTER })
        showScroll(root)
        videoUri?.let { videoView?.setVideoURI(it) }
    }

    private fun showScroll(content: LinearLayout) {
        scroll = ScrollView(this).apply { isFillViewport = true; addView(content) }
        setContentView(scroll)
    }
    private fun pick(code: Int, mime: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = mime }
        startActivityForResult(i, code)
    }
    private fun folders() {
        root = page()
        root.addView(label("مدير الملفات", 24f, white, true))
        space(root, 5)
        root.addView(label("اختَر مجلداً لعرض ملفات الفيديو داخله وحتى داخل المجلدات الفرعية.", 12f, muted))
        space(root, 12)
        button(root, "＋  اختيار مجلد من الجهاز", cyan) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_FOLDER)
        }
        button(root, "عرض فيديوهات المجلد المحدد") {
            val u = folderUri
            if (u == null) Toast.makeText(this, "اختَر مجلداً أولاً", Toast.LENGTH_SHORT).show()
            else { if (root.childCount > 7) root.removeViews(7, root.childCount - 7); scanTree(u, 0) }
        }
        button(root, "رجوع للرئيسية") { home() }
        folderUri?.let { scanTree(it, 0) }
        showScroll(root)
    }
    private fun scanTree(tree: Uri, depth: Int) {
        if (depth > 8) return
        try {
            val docId = if (depth == 0) DocumentsContract.getTreeDocumentId(tree) else return
            scanDocument(tree, docId, depth)
        } catch (_: Exception) {
            root.addView(label("تعذر قراءة المجلد المحدد.", 12f, muted))
        }
    }
    private fun scanDocument(tree: Uri, docId: String, depth: Int) {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        contentResolver.query(children,
            arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0); val name = c.getString(1) ?: "ملف"
                val mime = c.getString(2) ?: ""
                if (mime.startsWith("video/")) {
                    val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                    button(root, "▶   $name", panel2) {
                        videoUri = uri; videoName = name; home()
                        videoView?.setVideoURI(uri); videoView?.start()
                    }
                } else if (mime == DocumentsContract.Document.MIME_TYPE_DIR && depth < 7) {
                    val nested = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                    val nestedId = DocumentsContract.getDocumentId(nested)
                    scanDocument(tree, nestedId, depth + 1)
                }
            }
        }
    }
    private fun showLibrary() {
        root = page()
        root.addView(label("مكتبة الفيديو", 24f, white, true))
        space(root, 8)
        button(root, "اختيار فيديو من الجهاز") { pick(REQ_VIDEO, "video/*") }
        button(root, "فتح مدير الملفات") { folders() }
        button(root, "رجوع للرئيسية") { home() }
        showScroll(root)
    }
    private fun settings() {
        root = page()
        root.addView(label("الإعدادات", 24f, white, true))
        val prefs = getSharedPreferences("ameer", MODE_PRIVATE)
        space(root, 14)
        val keep = Switch(this).apply {
            text = "إبقاء الشاشة مضاءة"; setTextColor(white)
            isChecked = prefs.getBoolean("keep_screen", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("keep_screen", checked).apply()
                if (checked) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
        root.addView(keep)
        button(root, "معلومات التطبيق") {
            AlertDialog.Builder(this).setTitle("أمير للشاشات")
                .setMessage("مشغل الوسائط الذكي\\nالإصدار 2.0")
                .setPositiveButton("حسناً", null).show()
        }
        button(root, "رجوع للرئيسية") { home() }
        showScroll(root)
    }
    private fun openBrowser() {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))) }
        catch (_: Exception) { Toast.makeText(this, "تعذر فتح المتصفح", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Legacy document picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            contentResolver.takePersistableUriPermission(uri, data.flags and
                (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION))
        } catch (_: Exception) {}
        when (requestCode) {
            REQ_FOLDER -> {
                folderUri = uri
                getSharedPreferences("ameer", MODE_PRIVATE).edit().putString("folder_uri", uri.toString()).apply()
                folders()
            }
            REQ_VIDEO -> {
                videoUri = uri
                videoName = uri.lastPathSegment?.substringAfterLast('/') ?: "فيديو محدد"
                home(); videoView?.setVideoURI(uri); videoView?.start()
            }
            REQ_AUDIO -> {
                try {
                    player?.release()
                    player = MediaPlayer().apply {
                        setDataSource(this@MainActivity, uri)
                        setOnPreparedListener { it.start() }; prepareAsync()
                    }
                } catch (_: Exception) { Toast.makeText(this, "تعذر تشغيل الصوت", Toast.LENGTH_SHORT).show() }
            }
            REQ_IMAGE -> try {
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "image/*"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            } catch (_: Exception) {}
        }
    }
    override fun onResume() {
        super.onResume()
        if (getSharedPreferences("ameer", MODE_PRIVATE).getBoolean("keep_screen", true))
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    override fun onDestroy() {
        try { player?.release() } catch (_: Exception) {}
        executor.shutdown()
        super.onDestroy()
    }
}
