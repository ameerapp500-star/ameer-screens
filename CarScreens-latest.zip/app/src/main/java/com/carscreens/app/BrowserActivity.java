package com.carscreens.app;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BrowserActivity extends Activity {
  WebView w; EditText ed; FrameLayout root; LinearLayout col; View custom;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    col = new LinearLayout(this);
    col.setOrientation(LinearLayout.VERTICAL);
    col.setBackgroundColor(0xFF0B0B0B);
    ed = new EditText(this);
    ed.setSingleLine(true); ed.setTextColor(0xFFFFFFFF); ed.setHintTextColor(0xFF888888);
    ed.setHint("ابحث أو اكتب رابط"); ed.setImeOptions(EditorInfo.IME_ACTION_GO);
    ed.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
    ed.setOnEditorActionListener(new TextView.OnEditorActionListener() {
      public boolean onEditorAction(TextView v, int a, KeyEvent e) { go(ed.getText().toString()); return true; }
    });
    w = new WebView(this);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
    CookieManager.getInstance().setAcceptCookie(true);
    CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
    w.setWebViewClient(new WebViewClient() {
      @Override public void onPageStarted(WebView v, String u, Bitmap f) { ed.setText(u); }
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        String u = r.getUrl().toString();
        if (u.startsWith("http")) return false;
        try { Intent i = u.startsWith("intent:") ? Intent.parseUri(u, Intent.URI_INTENT_SCHEME) : new Intent(Intent.ACTION_VIEW, Uri.parse(u)); startActivity(i); } catch (Exception e) {}
        return true;
      }
    });
    root = new FrameLayout(this);
    w.setWebChromeClient(new WebChromeClient() {
      @Override public void onShowCustomView(View v, CustomViewCallback c) { custom = v; root.addView(v); col.setVisibility(View.GONE); }
      @Override public void onHideCustomView() { root.removeView(custom); custom = null; col.setVisibility(View.VISIBLE); }
    });
    LinearLayout bar = new LinearLayout(this);
    bar.setBackgroundColor(0xFF111111);
    bar.addView(btn("◀", new View.OnClickListener() { public void onClick(View v) { if (w.canGoBack()) w.goBack(); }}));
    bar.addView(btn("▶", new View.OnClickListener() { public void onClick(View v) { if (w.canGoForward()) w.goForward(); }}));
    bar.addView(btn("🏠", new View.OnClickListener() { public void onClick(View v) { finish(); }}));
    bar.addView(btn("⟳", new View.OnClickListener() { public void onClick(View v) { w.reload(); }}));
    col.addView(ed, new LinearLayout.LayoutParams(-1, -2));
    col.addView(w, new LinearLayout.LayoutParams(-1, 0, 1f));
    col.addView(bar, new LinearLayout.LayoutParams(-1, -2));
    root.addView(col);
    setContentView(root);
    String u = getIntent().getStringExtra("u");
    w.loadUrl(u == null ? "https://www.google.com" : u);
  }

  Button btn(String t, View.OnClickListener l) {
    Button x = new Button(this);
    x.setText(t); x.setOnClickListener(l);
    x.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
    return x;
  }

  void go(String s) {
    s = s.trim();
    if (s.length() == 0) return;
    if (s.startsWith("http")) w.loadUrl(s);
    else if (s.indexOf(' ') < 0 && s.indexOf('.') > 0) w.loadUrl("https://" + s);
    else w.loadUrl("https://www.google.com/search?q=" + Uri.encode(s));
  }

  @Override public void onBackPressed() {
    if (custom != null) { w.getWebChromeClient().onHideCustomView(); return; }
    if (w.canGoBack()) w.goBack(); else finish();
  }
  @Override protected void onDestroy() { w.destroy(); super.onDestroy(); }
}
