
package com.ameerscreens.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val serverUrl = "https://ameer-activation.ameerapp500.workers.dev"
    private val pickVideoRequest = 4102
    private var selectedVideo: Uri? = null
    private lateinit var root: LinearLayout

    private val bg = Color.rgb(9, 15, 29)
    private val panel = Color.rgb(20, 31, 51)
    private val accent = Color.rgb(0, 190, 170)
    private val muted = Color.rgb(160, 174, 195)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val prefs = getSharedPreferences("ameer", MODE_PRIVATE)
        if (prefs.getBoolean("activated", false)) showHome() else showActivation()
    }

    private fun basePage(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(18), dp(20), dp(20))
        setBackgroundColor(bg)
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun showActivation() {
        val page = basePage().apply { gravity = Gravity.CENTER }
        val title = label("أمير للشاشات", 30f, Color.WHITE, true)
        page.addView(title)
        page.addView(label("مشغل الوسائط للسيارة والهاتف", 15f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(28))
        })
        val status = label("نسخة مستقلة - أدخل كود التفعيل", 15f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(18))
        }
        page.addView(status)
        val input = EditText(this).apply {
            hint = "أدخل كود التفعيل"
            textSize = 16f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(muted)
            setPadding(dp(16), dp(13), dp(16), dp(13))
            setBackgroundColor(panel)
        }
        page.addView(input, matchWrap())
        val activate = Button(this).apply { text = "تفعيل التطبيق" }
        page.addView(activate, matchWrap().apply { topMargin = dp(16) })
        activate.setOnClickListener {
            val code = input.text.toString().trim()
            if (code.isEmpty()) {
                input.error = "أدخل كود التفعيل"
                return@setOnClickListener
            }
            activate.isEnabled = false
            activate.text = "جارٍ التحقق..."
            executor.execute {
                var ok = false
                var message = "تعذر الاتصال بالخادم"
                try {
                    val c = URL(serverUrl).openConnection() as HttpURLConnection
                    c.requestMethod = "POST"
                    c.connectTimeout = 15000
                    c.readTimeout = 15000
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.outputStream.use {
                        it.write(JSONObject().put("code", code).toString().toByteArray(Charsets.UTF_8))
                    }
                    val rc = c.responseCode
                    val stream = if (rc in 200..299) c.inputStream else c.errorStream
                    val response = stream?.bufferedReader()?.use { it.readText() } ?: ""
                    c.disconnect()
                    if (response.isNotBlank()) {
                        val result = JSONObject(response)
                        ok = rc == 200 && result.optBoolean("activated", false)
                        message = result.optString("message", "كود التفعيل غير صحيح")
                    }
                } catch (_: Exception) {
                    message = "تعذر الاتصال بالخادم"
                }
                runOnUiThread {
                    activate.isEnabled = true
                    activate.text = "تفعيل التطبيق"
                    if (ok) {
                        getSharedPreferences("ameer", MODE_PRIVATE)
                            .edit().putBoolean("activated", true).apply()
                        showHome()
                    } else {
                        status.text = message
                        status.setTextColor(Color.RED)
                    }
                }
            }
        }
        setContentView(page)
    }

    private fun showHome() {
        root = basePage()
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        brand.addView(label("أمير للشاشات", 25f, Color.WHITE, true))
        brand.addView(label("AMeer Screens Player", 12f, muted))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val statusChip = label("● جاهز", 13f, accent, true).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(panel)
        }
        header.addView(statusChip)
        root.addView(header)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            setBackgroundColor(Color.rgb(17, 52, 68))
        }
        val heroTitle = label("مكتبة الفيديو", 22f, Color.WHITE, true)
        hero.addView(heroTitle)
        hero.addView(label("اختر فيديو من جهازك وشغّله مباشرة", 14f, Color.rgb(205, 224, 232)).apply {
            setPadding(0, dp(7), 0, dp(15))
        })
        val choose = Button(this).apply {
            text = "＋  اختيار فيديو"
            setTextColor(Color.WHITE)
            setBackgroundColor(accent)
        }
        hero.addView(choose, LinearLayout.LayoutParams(-1, dp(50)))
        choose.setOnClickListener { openVideoPicker() }
        val heroParams = matchWrap().apply { topMargin = dp(24) }
        root.addView(hero, heroParams)

        root.addView(sectionTitle("التشغيل الآن"), matchWrap().apply {
            topMargin = dp(24)
        })
        val playerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
        }
        val videoView = VideoView(this)
        videoView.tag = "video_view"
        playerCard.addView(videoView, LinearLayout.LayoutParams(-1, dp(205)))
        val nowPlaying = label("لم يتم اختيار فيديو بعد", 15f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(12))
            tag = "now_playing"
        }
        playerCard.addView(nowPlaying)
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val replay = Button(this).apply {
            text = "↺"
            textSize = 20f
        }
        val play = Button(this).apply {
            text = "▶"
            textSize = 20f
            tag = "play_button"
        }
        val stop = Button(this).apply {
            text = "■"
            textSize = 20f
        }
        controls.addView(replay, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(play, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(stop, LinearLayout.LayoutParams(0, dp(48), 1f))
        playerCard.addView(controls)
        root.addView(playerCard, matchWrap())

        play.setOnClickListener {
            if (selectedVideo == null) openVideoPicker()
            else if (videoView.isPlaying) {
                videoView.pause()
                play.text = "▶"
            } else {
                videoView.start()
                play.text = "Ⅱ"
            }
        }
        replay.setOnClickListener {
            if (selectedVideo != null) {
                videoView.seekTo(0)
                videoView.start()
                play.text = "Ⅱ"
            }
        }
        stop.setOnClickListener {
            if (selectedVideo != null) {
                videoView.stopPlayback()
                videoView.setVideoURI(selectedVideo)
                play.text = "▶"
            }
        }
        videoView.setOnCompletionListener {
            play.text = "▶"
        }

        root.addView(sectionTitle("اختصارات"), matchWrap().apply {
            topMargin = dp(22)
        })
        val shortcuts = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        shortcuts.addView(shortcut("🎬", "الفيديوهات"),
            LinearLayout.LayoutParams(0, dp(92), 1f))
        shortcuts.addView(shortcut("📁", "المجلدات"),
            LinearLayout.LayoutParams(0, dp(92), 1f).apply {
                leftMargin = dp(8)
                rightMargin = dp(8)
            })
        shortcuts.addView(shortcut("⚙", "الإعدادات"),
            LinearLayout.LayoutParams(0, dp(92), 1f))
        root.addView(shortcuts)
        root.addView(label("أمير للشاشات  •  الإصدار 1.0", 11f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        })
        val scroll = ScrollView(this).apply {
            addView(root)
        }
        setContentView(scroll)
    }

    private fun openVideoPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, pickVideoRequest)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideoRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            selectedVideo = uri
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            val video = findViewWithTag<VideoView>("video_view")
            val title = findViewWithTag<TextView>("now_playing")
            val play = findViewWithTag<Button>("play_button")
            video?.setVideoURI(uri)
            title?.text = "تم اختيار الفيديو — اضغط تشغيل"
            play?.text = "▶"
            Toast.makeText(this, "تم اختيار الفيديو", Toast.LENGTH_SHORT).show()
        }
    }

    private fun <T : View> findViewWithTag(tagValue: String): T? =
        findViewByTagRecursive(root, tagValue)

    @Suppress("UNCHECKED_CAST")
    private fun <T : View> findViewByTagRecursive(
        parent: android.view.ViewGroup,
        tagValue: String
    ): T? {
        for (i in 0 until parent.childCount) {
            val child = parent.getChildAt(i)
            if (child.tag == tagValue) return child as T
            if (child is android.view.ViewGroup) {
                val found = findViewByTagRecursive<T>(child, tagValue)
                if (found != null) return found
            }
        }
        return null
    }

    private fun label(
        textValue: String,
        size: Float,
        color: Int,
        bold: Boolean = false
    ) = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun sectionTitle(textValue: String) =
        label(textValue, 18f, Color.WHITE, true).apply {
            setPadding(0, dp(4), 0, dp(12))
        }

    private fun shortcut(symbol: String, caption: String) =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(panel)
            addView(label(symbol, 25f, accent))
            addView(label(caption, 12f, Color.WHITE, true).apply {
                setPadding(0, dp(7), 0, 0)
            })
        }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)

    private fun dp(value: Int) =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
