
package com.ameerscreens.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 18, 34)
        window.navigationBarColor = Color.rgb(10, 18, 34)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(10, 18, 34))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        page.addView(TextView(this).apply {
            text = "أمير للشاشات"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })

        page.addView(TextView(this).apply {
            text = "نسخة مستقلة قيد الإعداد"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 28)
        })

        page.addView(EditText(this).apply {
            hint = "أدخل كود التفعيل"
            textSize = 16f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(30, 43, 65))
        }, LinearLayout.LayoutParams(-1, -2))

        page.addView(Button(this).apply {
            text = "تفعيل"
            setOnClickListener {
                Toast.makeText(
                    this@MainActivity,
                    "خادم التفعيل لم يُربط بعد. هذه نسخة تأسيسية وليست إصداراً نهائياً.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = 18
        })

        page.addView(TextView(this).apply {
            text = "التفعيل مدى الحياة لكل جهاز — سيُفعّل بعد إعداد خادم التراخيص."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        })

        setContentView(page)
    }
}
