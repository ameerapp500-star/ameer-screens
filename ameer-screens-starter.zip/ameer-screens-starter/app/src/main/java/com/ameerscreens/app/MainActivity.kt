
package com.ameerscreens.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val executor = Executors.newSingleThreadExecutor()

    private val serverUrl =
        "https://ameer-activation.ameerapp500.workers.dev"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(10, 18, 34)
        window.navigationBarColor = Color.rgb(10, 18, 34)

        val prefs = getSharedPreferences("ameer", MODE_PRIVATE)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(10, 18, 34))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "أمير للشاشات"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        page.addView(title)

        val status = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 28)
        }
        page.addView(status)

        val input = EditText(this).apply {
            hint = "أدخل كود التفعيل"
            textSize = 16f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(30, 43, 65))
        }

        page.addView(input, LinearLayout.LayoutParams(-1, -2))

        val activateButton = Button(this).apply {
            text = "تفعيل"
        }

        page.addView(
            activateButton,
            LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = 18
            }
        )

        if (prefs.getBoolean("activated", false)) {
            status.text = "تم تفعيل التطبيق على هذا الجهاز"
            input.visibility = View.GONE
            activateButton.visibility = View.GONE
        } else {
            status.text = "نسخة مستقلة - أدخل كود التفعيل"
        }

        activateButton.setOnClickListener {
            val code = input.text.toString().trim()

            if (code.isEmpty()) {
                input.error = "أدخل كود التفعيل"
                return@setOnClickListener
            }

            activateButton.isEnabled = false
            activateButton.text = "جارٍ التحقق..."

            executor.execute {
                var activated = false
                var message = "تعذر الاتصال بالخادم"

                try {
                    val connection =
                        URL(serverUrl).openConnection() as HttpURLConnection

                    connection.requestMethod = "POST"
                    connection.connectTimeout = 15000
                    connection.readTimeout = 15000
                    connection.doOutput = true

                    connection.setRequestProperty(
                        "Content-Type",
                        "application/json"
                    )

                    val json = JSONObject().put("code", code)

                    connection.outputStream.use {
                        it.write(json.toString().toByteArray(Charsets.UTF_8))
                    }

                    val responseCode = connection.responseCode

                    val stream = if (responseCode in 200..299) {
                        connection.inputStream
                    } else {
                        connection.errorStream
                    }

                    val response = stream?.bufferedReader()?.use {
                        it.readText()
                    } ?: ""

                    connection.disconnect()

                    if (response.isNotBlank()) {
                        val result = JSONObject(response)
                        activated =
                            responseCode == 200 &&
                            result.optBoolean("activated", false)

                        message = result.optString(
                            "message",
                            "كود التفعيل غير صحيح"
                        )
                    }

                } catch (e: Exception) {
                    message = "تعذر الاتصال بالخادم"
                }

                runOnUiThread {
                    activateButton.isEnabled = true
                    activateButton.text = "تفعيل"

                    if (activated) {
                        prefs.edit()
                            .putBoolean("activated", true)
                            .apply()

                        status.text = "تم التفعيل بنجاح ❤️"
                        status.setTextColor(Color.GREEN)
                        input.visibility = View.GONE
                        activateButton.visibility = View.GONE

                        Toast.makeText(
                            this,
                            "أهلاً بك في أمير للشاشات",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        status.text = message
                        status.setTextColor(Color.RED)
                    }
                }
            }
        }

        setContentView(page)
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
